<?php

// $con = mysqli_connect("localhost","pixelsva_new","GHP123ghp!@2020","pixelsva_new_pixels","3306");
$con = mysqli_connect("localhost","pixelsva_new","Q}#9w(#(HFYY","pixelsva_new_pixels","3306");

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}else
// print("Working")

?>