<nav class="navbar navbar-expand-lg margin_right_med">
                    
    <div class="container">
        <a class="navbar-brand" href="/">
          <img src="img/expat_image.jpg" alt=""  class="logo-margin_left">
        </a>
     </div>

    <div class="container-fluid">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
        </button>
    
         <!--Navbar links -->
         
        
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
    
             
            <ul class="navbar-nav ml-auto">
    
                <li class="nav-item ml-5">
                    <a class="nav-link" href="#">
                        <i class="fa fa-file-text mr-1"></i> Questionaire
                    </a>
                </li>
    
                <li class="nav-item ml-5">
                    <a class="nav-link" href="#">
                        <i class="fa fa-file mr-1"></i> My Files
                    </a>
                </li>
                <li class="nav-item ml-5">
                    <a class="nav-link" href="#">
                        <i class="fa fa-phone mr-1"></i> Contact Us
                    </a>
                </li>
                
                <li class="nav-item dropdown ml-5">
    
                    <a class="nav-link" href="logout"> <i class="fa fa-user-circle mr-1"></i>Logout</a>
    
                </li>
                
            </ul>
        </div>
    
    </div>
    
</nav>